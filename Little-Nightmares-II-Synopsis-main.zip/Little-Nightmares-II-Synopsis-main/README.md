<h1 align="center"> Little Nightmares II - Synopsis</h1>

<p align="center">
project aimed at electronic game companies and the gamer community. <br/>
</p>

<p align="center">
  <a href="#-Preview">Preview</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
  <a href="#-tecnologias">technologies</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
  <a href="#-projeto">Project</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</p>

<br>

## 🔖 Preview

see the preview of the project:

<img alt="This is the project preview" src="./src/imagens/imagePreview.png" width="100%">

## 🚀 technologies

This project was developed with the following technologies:

- HTML e CSS
- JavaScript
- Git e Github

## 💻 Project

The project and synopsis of the game Little Nightmare II. 

- [Visit the project online] (https://dan1nicolas.github.io/Little-Nightmares-II-Synopsis/)

---

Made with ♥ 
<br>
Daniel Nicolas Leoterio
